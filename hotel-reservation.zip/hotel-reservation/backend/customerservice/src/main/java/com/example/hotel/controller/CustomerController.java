package com.example.hotel.controller;

import com.example.hotel.dto.CustomerDto;
import com.example.hotel.jwt.JwtHelper;
import com.example.hotel.model.Customer;
import com.example.hotel.response.CustomerResponse;
import com.example.hotel.model.RefreshToken;
import com.example.hotel.service.ICustomerService;
import com.example.hotel.service.IRefreshTokenService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.regex.*;

import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import javax.validation.constraints.Email;
import java.util.HashMap;

@CrossOrigin
@RestController
@RequiredArgsConstructor
public class CustomerController {

    // Dependency Injection using required args constructor from lombok
    private final ICustomerService customerService;  // CustomerService is a service class
    private final AuthenticationManager authenticationManager;  // Spring Security authentication manager
    private final IRefreshTokenService refreshTokenService; // interface for refresh tokens
    private final PasswordEncoder passwordEncoder;   // Password encoder for password hashing
    private final JwtHelper helper; // JWT helper class

    @PostMapping("/register")
    @Transactional
    private ResponseEntity<?> addCustomer(@RequestBody CustomerDto c) {
        HashMap<String, String> body = new HashMap<>();
        try {
            String email=body.get("email");
            String emailRegexPattern = "[^@ \\t\\r\\n]+@[^@ \\t\\r\\n]+\\.[^@ \\t\\r\\n]+";
            String phoneNumberRegex = "^[\\+]?[(]?[0-9]{3}[)]?[-\\s\\.]?[0-9]{3}[-\\s\\.]?[0-9]{4,6}$";
            String passwordPattern = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$";
            body.put("msg", "");
            boolean isEmailValid = Pattern.matches(emailRegexPattern, c.getEmail());
            boolean isValidPassword = Pattern.matches(passwordPattern, c.getPassword());
            boolean isValidPhoneNumber = Pattern.matches(phoneNumberRegex, c.getPhoneNumber());

            if (customerService.getCustomerByEmail(c.getEmail())!=null){
                body.put("msg","Email already exists");
                return new ResponseEntity<>(body,HttpStatus.BAD_REQUEST);
            }
            if (isEmailValid && isValidPassword && isValidPhoneNumber) {
                Customer customer = new Customer(c.getFirstName(), c.getLastName(), c.getEmail(), passwordEncoder.encode(c.getPassword()), c.getPhoneNumber(), c.getAddress());
                customerService.addCustomer(customer);
                RefreshToken refreshToken = new RefreshToken();
                refreshToken.setCustomer(customer);
                refreshTokenService.saveRefreshToken(refreshToken);
                customer.setToken(refreshToken);
                customerService.updateCustomer(customer);

                String accessToken = helper.generateAccessToken(customer);
                String refreshTokenString = helper.generateRefreshToken(customer, String.valueOf(refreshToken.getId()));
                CustomerResponse response = new CustomerResponse(customer.getCustomerId(), accessToken, refreshTokenString);
                return ResponseEntity.ok().body(response);
            }
            if (!isEmailValid) {
                body.put("msg", "enter a valid email");
            }
            if (!isValidPassword) {
                body.put("msg", "enter a valid password");
            }
            if (!isValidPhoneNumber) {
                body.put("msg", "enter a valid Phone number");
            }
            return ResponseEntity.badRequest().body(body);
        } catch (Exception e) {
            body.put("msg", e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/login")
    @Transactional
    private ResponseEntity<?> customerLogin(@RequestBody HashMap<String, String> body) {
        HashMap<String, String> res = new HashMap<>();
        try {
            String email = body.get("email");
            String password = body.get("password");
            Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            Customer c = (Customer) authentication.getPrincipal();
            RefreshToken refreshToken = new RefreshToken();
            refreshToken.setCustomer(c);
            refreshTokenService.saveRefreshToken(refreshToken);
            String accessToken = helper.generateAccessToken(c);
            String refreshTokenString = helper.generateRefreshToken(c, String.valueOf(refreshToken.getId()));
            c.setToken(refreshToken);
            customerService.updateCustomer(c);
            CustomerResponse response = new CustomerResponse(c.getCustomerId(), accessToken, refreshTokenString);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            res.put("msg", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/logout")
    private ResponseEntity<?> logout() {
        HashMap<String, String> res = new HashMap<>();
        try {
            Customer c = (Customer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            RefreshToken refreshToken = c.getToken();
            c.setToken(null);
            customerService.updateCustomer(c);
            refreshTokenService.deleteRefreshTokenById(refreshToken.getId());
            SecurityContextHolder.setContext(SecurityContextHolder.createEmptyContext());
            res.put("msg", "logged out successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("msg", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}



