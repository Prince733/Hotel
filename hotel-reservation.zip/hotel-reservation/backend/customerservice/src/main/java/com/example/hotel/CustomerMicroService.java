package com.example.hotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerMicroService {

    public static void main(String[] args) {
        SpringApplication.run(CustomerMicroService.class, args);
    }

}
