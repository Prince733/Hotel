package com.example.hotel.service.impl;

import com.example.hotel.exception.UserNotFoundException;
import com.example.hotel.model.Customer;
import com.example.hotel.repository.ICustomerRepository;
import com.example.hotel.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService implements ICustomerService {
    @Autowired
    public ICustomerRepository repo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return repo.findByEmail(username);
    }

    public void saveCustomer(Customer c) {
        repo.save(c);
    }


    public Customer findByEmailAndPassword(String email, String password) {
        return repo.findByEmailAndPassword(email, password);
    }


    public Customer findByEmail(String email) {
        return repo.findByEmail(email);
    }

    public void addCustomer(Customer c) {
        repo.save(c);
    }


    public List<Customer> findAll() {
        return repo.findAll();
    }


    public Customer findById(Long id) {
        return repo.findById(id).orElseThrow(() -> new UserNotFoundException("Customer not found"));
    }

    public void deleteCustomer(Long id) {
        repo.deleteById(id);
    }


    public void updateCustomer(Customer c) {
        repo.save(c);
    }


    public Customer findByToken(String token) {
        return repo.findByToken(token);
    }

    @Override
    public Customer getCustomerByEmail(String s) {
        return repo.findByEmail(s);
    }
}

