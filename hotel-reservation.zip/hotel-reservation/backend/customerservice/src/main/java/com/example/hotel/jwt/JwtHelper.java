package com.example.hotel.jwt;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.example.hotel.model.Customer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;

@Slf4j
@Component
public class JwtHelper {
    private static final String SECRET = "secret";
    public static final String ISSUER = "hotelManagement";
    private static final long ACCESS_EXPIRATION_TIME = 864_000_000; // 10 days
    private static final long REFRESH_EXPIRATION_TIME = 604_800_000; // 7 days
    private final JWTVerifier accessTokenVerifier;
    private final Algorithm refreshTokenAlgorithm = Algorithm.HMAC256(SECRET);
    private final Algorithm accessTokenAlgorithm = Algorithm.HMAC256(SECRET);

    public JwtHelper() {
        accessTokenVerifier = JWT.require(accessTokenAlgorithm).withIssuer(ISSUER).build();
    }


    public String generateAccessToken(Customer customer) {
        return JWT.create().
                withSubject(customer.getCustomerId().toString())
                .withIssuer(ISSUER).withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + ACCESS_EXPIRATION_TIME))
                .sign(accessTokenAlgorithm);
    }

    public String generateRefreshToken(Customer customer, String tokenId) {
        return JWT.create().withSubject(customer.getCustomerId().toString()).withIssuer(ISSUER).withClaim("tokenId", tokenId).withIssuedAt(new Date()).withExpiresAt(new Date(System.currentTimeMillis() + REFRESH_EXPIRATION_TIME)).sign(refreshTokenAlgorithm);
    }

    private Optional<DecodedJWT> decodeAccessToken(String token) {
        try {
            return Optional.of(accessTokenVerifier.verify(token));
        } catch (JWTVerificationException e) {
            log.error("Invalid access token", e);
            return Optional.empty();
        }
    }

    private Optional<DecodedJWT> decodeRefreshToken(String token) {
        try {
            return Optional.of(accessTokenVerifier.verify(token));
        } catch (JWTVerificationException e) {
            log.error("Invalid refresh token", e);
            return Optional.empty();
        }
    }

    public boolean validateAccessToken(String token) {
        return decodeAccessToken(token).isPresent();
    }

    public boolean validateRefreshToken(String token) {
        return decodeRefreshToken(token).isPresent();
    }

    public String getSubjectFromAccessToken(String token) {
        return decodeAccessToken(token).isPresent() ? decodeAccessToken(token).get().getSubject() : null;
    }

    public String getSubjectFromRefreshToken(String token) {
        return decodeRefreshToken(token).isPresent() ? decodeRefreshToken(token).get().getSubject() : null;
    }

    public String getTokenIdFromRefreshToken(String token) {
        return decodeRefreshToken(token).isPresent() ? decodeRefreshToken(token).get().getClaim("tokenId").asString() : null;
    }
}
