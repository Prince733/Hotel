package com.example.hotel.repository;

import com.example.hotel.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Long> {
    Customer findByEmailAndPassword(String email, String password);

    Customer findByEmail(String email);

    Customer findByToken(String token);
}
