package com.example.hotel.service;

import com.example.hotel.model.Customer;
import com.example.hotel.service.impl.CustomerService;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface ICustomerService extends UserDetailsService {

    Customer findByEmailAndPassword(String email, String password);

    Customer findByEmail(String email);

    void addCustomer(Customer c);

    Customer findById(Long id);

    void deleteCustomer(Long id);

    void updateCustomer(Customer c);

    List<Customer> findAll();

    Customer findByToken(String token);

    Customer getCustomerByEmail(String s);
}
