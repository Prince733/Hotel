package com.example.hotel.service;

import com.example.hotel.model.RefreshToken;

public interface IRefreshTokenService {

    RefreshToken saveRefreshToken(RefreshToken refreshToken);

    void deleteRefreshTokenById(Long id);

    RefreshToken findById(Long id);
}
