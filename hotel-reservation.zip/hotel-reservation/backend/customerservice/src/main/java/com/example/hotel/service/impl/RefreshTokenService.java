package com.example.hotel.service.impl;

import com.example.hotel.exception.TokenNotFoundException;
import com.example.hotel.model.RefreshToken;
import com.example.hotel.repository.IRefreshTokenRepository;
import com.example.hotel.service.IRefreshTokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RefreshTokenService implements IRefreshTokenService {

    @Autowired
    private IRefreshTokenRepository repo;

    @Override
    public RefreshToken saveRefreshToken(RefreshToken refreshToken) {
        return repo.save(refreshToken);
    }

    @Override
    public void deleteRefreshTokenById(Long id) {
        repo.deleteById(id);
    }

    @Override
    public RefreshToken findById(Long id) {
        return repo.findById(id).orElseThrow(() -> new TokenNotFoundException("Token not found"));
    }

}
