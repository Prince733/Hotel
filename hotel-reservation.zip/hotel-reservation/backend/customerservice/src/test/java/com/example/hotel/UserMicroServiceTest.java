package com.example.hotel;

import com.example.hotel.dto.CustomerDto;
import com.example.hotel.exception.UserNotFoundException;
import com.example.hotel.model.Customer;
import com.example.hotel.response.CustomerResponse;
import com.example.hotel.service.ICustomerService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@SpringBootTest
public class UserMicroServiceTest {

    @Autowired
    private ICustomerService service;

    @Order(1)
    @Test
    void testServiceIsNotNull() {
        assert service != null;
    }

    @Order(2)
    @Test
    void addCustomer() {
        Customer customer = new Customer();
        customer.setFirstName("John");
        customer.setLastName("Doe");
        customer.setAddress("123 Main St");
        customer.setEmail("johndoe@gmail.com");
        service.addCustomer(customer);
        assert service.getCustomerByEmail("johndoe@gmail.com").getFirstName().equals("John");
    }

    @Order(3)
    @Test
    void getCustomer() {
        assert service.getCustomerByEmail("johndoe@gmail.com") == null;
    }


    @Order(4)
    @Test
    void updateCustomer() {
        Customer customer = service.getCustomerByEmail("johndoe@gmail.com");
        customer.setFirstName("Jane");
        service.updateCustomer(customer);
        assert service.getCustomerByEmail("johndoe@gmail.com").getFirstName().equals("Jane");
    }


    @Order(5)
    @Test
    void deleteCustomer() {
        assert service.getCustomerByEmail("johndoe@gmail.com") == null;
    }

    @Test
    @Order(6)
    void dtoCheck(){
        CustomerDto r = new CustomerDto();
        if(r == null){
            throw new UserNotFoundException("User not found");
        }
        assert r != null;
    }

    @Test
    @Order(7)
    void CustomerResponseCheck(){
        CustomerResponse c = new CustomerResponse();
        if(c == null){
            throw new UserNotFoundException("User not found");
        }
        assert c != null;
    }



}
