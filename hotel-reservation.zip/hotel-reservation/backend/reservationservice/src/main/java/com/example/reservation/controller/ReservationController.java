package com.example.reservation.controller;

import com.example.reservation.dto.ReservationDto;
import com.example.reservation.dto.RoomSearchDto;
import com.example.reservation.jwt.JwtHelper;
import com.example.reservation.model.Reservation;
import com.example.reservation.model.Room;
import com.example.reservation.service.IReservationService;
import com.example.reservation.service.impl.ReservationService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;

@RestController
@CrossOrigin
@RequiredArgsConstructor

public class ReservationController {
    private final IReservationService reservationService;
    private final JwtHelper helper;
    private final HttpServletRequest req;

    private final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    // Custom endpoints

    // Searching reservation by room type and date from and to and return the result
    @PostMapping("/rooms/search")
    private ResponseEntity<?> searchRoom(@RequestBody RoomSearchDto roomSearchDto,@RequestHeader(name = "Authorization", required = true) String token)  {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                if (roomSearchDto.getRoomType() == null
                        || roomSearchDto.getFromDate() == null
                        || roomSearchDto.getToDate() == null) {
                    map.put("message", "Please provide all the required fields");
                    return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
                }
                List<Room> rooms = reservationService.searchRoom(
                        roomSearchDto.getRoomType(),
                        LocalDate.parse(roomSearchDto.getFromDate(), FORMATTER),
                        LocalDate.parse(roomSearchDto.getToDate(), FORMATTER));
                if(rooms.size() == 0){
                    map.put("msg","Please choose other categories");
                    return new ResponseEntity<>(map, HttpStatus.OK);
                }else{
                    return new ResponseEntity<>(rooms, HttpStatus.OK);
                }

            } else {
                map.put("message", "User is not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("error", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
        }
    }


    // endpoint for adding a reservation
    @PostMapping("/reservation")
    private ResponseEntity<?> addReservation(@RequestBody ReservationDto r,@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                if (r.getRoomId() == 0 || r.getFromDate() == null || r.getToDate() == null) {
                    map.put("message", "Please provide all the required fields");
                    return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
                }
                if (reservationService.getRoomById(r.getRoomId()) == null) {
                    map.put("message", "Room not found");
                    return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
                }
                //builder pattern for creating a reservation
                if (reservationService.getRoomById(r.getRoomId()).getIsBooked()){
                    map.put("message", "Room is already booked");
                    return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
                }
                Reservation reservation = Reservation.builder().
                        room(reservationService.getRoomById(r.getRoomId())).
                        fromDate(LocalDate.parse(r.getFromDate(), FORMATTER)).
                        customerId(helper.getCustomerIdFromToken(req)).
                        toDate(LocalDate.parse(r.getToDate(), FORMATTER)).
                        build();
                Room room = reservationService.getRoomById(r.getRoomId());
                room.setIsBooked(true);
                reservationService.updateRoom(room);
                map.put("message", "Reserved Room successfully");
                reservationService.addReservation(reservation);
                return new ResponseEntity<>(map, HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // endpoint for getting all reservations
    @GetMapping("/reservations")
    private ResponseEntity<?> getAllReservations(@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                return new ResponseEntity<>(reservationService.getAllReservations(), HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // endpoint for deleting a reservation by id
    @DeleteMapping("/reservation/{id}")
    private ResponseEntity<?> deleteReservationById(@PathVariable Long id,@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                reservationService.deleteReservation(id);
                map.put("message", "Reservation deleted successfully");
                return new ResponseEntity<>(map, HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // endpoint for deleting all reservations
    @DeleteMapping("/reservations")
    private ResponseEntity<?> deleteAllReservations(@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                reservationService.deleteAllReservations();
                map.put("message", "All reservations deleted successfully");
                return new ResponseEntity<>(map, HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // endpoint for getting a room by id
    @GetMapping("/rooms/{id}")
    private ResponseEntity<?> getRoomById(@PathVariable Long id,@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                return new ResponseEntity<>(reservationService.getRoomById(id), HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // endpoint for getting reservation by id
    @GetMapping("/reservation/{id}")
    private ResponseEntity<?> getReservationById(@PathVariable Long id,@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                return new ResponseEntity<>(reservationService.getReservationById(id), HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // endpoint for updating a reservation
    @PutMapping("/reservation")
    private ResponseEntity<?> updateReservation(@RequestBody Reservation reservation,@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                reservationService.updateReservation(reservation);
                map.put("message", "Reservation updated successfully");
                return new ResponseEntity<>(map, HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //endpoint for adding a room
    @PostMapping("/room")
    private ResponseEntity<?> addRoom(@RequestBody Room r,@RequestHeader(name = "Authorization", required = true) String token) {
        HashMap<String, String> map = new HashMap<>();
        try {
            if (helper.isUserVerified(req)) {
                map.put("message", "Room added successfully");
                reservationService.addRoom(r);
                return new ResponseEntity<>(map, HttpStatus.OK);
            } else {
                map.put("message", "User not verified");
                return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            map.put("message", e.getMessage());
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
