package com.example.reservation.jwt;


import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.auth0.jwt.JWT;

import javax.servlet.http.HttpServletRequest;

@Component
@Slf4j
public class JwtHelper {
    private static final String SECRET_KEY = "secret";
    private final JWTVerifier verifier;
    Algorithm algorithm = Algorithm.HMAC256(SECRET_KEY);

    public JwtHelper() {
        verifier = JWT.require(algorithm).build();
    }

    public boolean isUserVerified(HttpServletRequest req) {
        try {
            String token = req.getHeader("Authorization");
            if (token != null) {
                token = token.substring(7);
                DecodedJWT jwt = verifier.verify(token);
                return Long.parseLong(jwt.getSubject()) != 0L;
            } else {
                return false;
            }
        } catch (SignatureVerificationException e) {
            log.error("Error while getting user id from token");
            return false;
        }
    }

    public Long getCustomerIdFromToken(HttpServletRequest req) {
        try {
            String token = req.getHeader("Authorization");
            if (token != null) {
                token = token.substring(7);
                DecodedJWT jwt = verifier.verify(token);
                return Long.parseLong(jwt.getSubject());
            } else {
                return 0L;
            }
        } catch (SignatureVerificationException e) {
            log.error("Error while getting user id from token");
            return 0L;
        }
    }
}
