package com.example.reservation.repository;

import com.example.reservation.model.Reservation;
import com.example.reservation.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IReservationRepository extends JpaRepository<Reservation, Long> {

    @Query("SELECT r FROM Reservation r WHERE r.customerId = ?1")
    Reservation getReservationByCustomerId(Long id);
}
