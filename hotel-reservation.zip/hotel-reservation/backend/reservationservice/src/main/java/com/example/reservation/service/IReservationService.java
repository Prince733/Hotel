package com.example.reservation.service;

import com.example.reservation.model.Reservation;
import com.example.reservation.model.Room;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public interface IReservationService {
    void addReservation(Reservation reservation);

    void deleteReservation(Long id);

    void deleteAllReservations();

    Room getRoomById(Long id);

    Reservation getReservationById(Long id);

    void updateReservation(Reservation reservation);

    void updateRoom(Room room);

    List<Reservation> getAllReservations();
    
    List<Room> searchRoom(String roomType, LocalDate dateFrom, LocalDate dateTo);

    void addRoom(Room r);

    Room getByRoomNumber(String roomNumber);

    void deleteRoomByRoomNumber(String s);

    Reservation getReservationByCustomerId(Long id);
}
