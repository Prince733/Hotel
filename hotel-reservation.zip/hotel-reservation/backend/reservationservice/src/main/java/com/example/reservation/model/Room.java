package com.example.reservation.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long roomId;
    private String roomNbr;
    private String roomType;

    @OneToOne(mappedBy = "room")
    @JsonIgnore
    private Reservation reservation;

    private Boolean isBooked = false;

    public Room(String roomNbr, String roomType) {
        this.roomNbr = roomNbr;
        this.roomType = roomType;
        this.isBooked = Boolean.FALSE;
    }
}
