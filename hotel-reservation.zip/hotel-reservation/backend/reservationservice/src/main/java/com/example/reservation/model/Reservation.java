package com.example.reservation.model;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
@Builder
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long reservationId;

    private Long customerId;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "room_id")
    private Room room;
    private LocalDate fromDate;
    private LocalDate toDate;
    private Boolean checkInDone = false;

    public Reservation(LocalDate fromDate, LocalDate toDate, Boolean checkInDone) {
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.checkInDone = checkInDone;
    }
}
