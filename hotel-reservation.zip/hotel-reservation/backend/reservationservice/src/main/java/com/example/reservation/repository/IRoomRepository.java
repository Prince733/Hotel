package com.example.reservation.repository;

import com.example.reservation.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface IRoomRepository extends JpaRepository<Room, Long> {
    List<Room> getByRoomType(String roomType);

    Room getByRoomNbr(String roomNbr);

    @Query("SELECT r FROM Room r WHERE r.roomType = ?1 AND r.roomId NOT IN " +
            "(SELECT r.roomId FROM Reservation res JOIN res.room r WHERE res.fromDate <= ?2 " +
            "AND res.toDate >= ?3)")
    List<Room> searchRoom(String roomType, LocalDate fromDate, LocalDate toDate);

    void deleteByRoomNbr(String roomNbr);
}
