package com.example.reservation.service.impl;

import com.example.reservation.exception.ReservationNotFoundException;
import com.example.reservation.exception.RoomNotFoundException;
import com.example.reservation.model.Reservation;
import com.example.reservation.model.Room;
import com.example.reservation.repository.IReservationRepository;
import com.example.reservation.repository.IRoomRepository;
import com.example.reservation.service.IReservationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReservationService implements IReservationService {
    private final IReservationRepository reservationRepository;
    private final IRoomRepository roomRepository;

    public void addReservation(Reservation r) {
        reservationRepository.save(r);
    }

    @Override
    public void deleteReservation(Long id) {
        reservationRepository.deleteById(id);
    }

    @Override
    public void deleteAllReservations() {
        reservationRepository.deleteAll();
    }

    @Override
    public Room getRoomById(Long id) {
        return roomRepository.findById(id).orElseThrow(() -> new RoomNotFoundException("Room not found"));
    }

    @Override
    public Reservation getReservationById(Long id) {
        return reservationRepository.findById(id).orElseThrow(() -> new ReservationNotFoundException("Reservation not found"));
    }

    @Override
    public void updateReservation(Reservation reservation) {
        reservationRepository.save(reservation);
    }

    @Override
    public void updateRoom(Room room) {
        roomRepository.save(room);
    }

    @Override
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    @Override
    public List<Room> searchRoom(String roomType, LocalDate dateFrom, LocalDate dateTo) {
        return roomRepository.searchRoom(roomType, dateFrom, dateTo);
    }

    @Override
    public void addRoom(Room r) {
        roomRepository.save(r);
    }

    @Override
    public Room getByRoomNumber(String roomNumber) {
        return roomRepository.getByRoomNbr(roomNumber);
    }

    @Override
    public void deleteRoomByRoomNumber(String s) {
        Room r = roomRepository.getByRoomNbr(s);
        roomRepository.delete(r);
    }

    @Override
    public Reservation getReservationByCustomerId(Long id) {
        return reservationRepository.getReservationByCustomerId(id);
    }
}
