package com.example.reservation;

import com.example.reservation.dto.ReservationDto;
import com.example.reservation.dto.RoomSearchDto;
import com.example.reservation.exception.ReservationNotFoundException;
import com.example.reservation.exception.RoomNotFoundException;
import com.example.reservation.model.Reservation;
import com.example.reservation.model.Room;
import com.example.reservation.service.IReservationService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ReservationServiceTest {

    @Autowired
    private IReservationService service;

    @Test
    @Order(1)
    void testRoomServiceIsNotNull() {
        assert service != null;
    }

    @Test
    @Order(2)
    void addRoom() {
        Room room = new Room();
        room.setRoomType("Deluxe");
        room.setRoomNbr("101");
        room.setReservation(null);
        service.addRoom(room);

        assert service.getByRoomNumber("101").getRoomType().equals("Deluxe");
    }

    @Test
    @Order(3)
    void updateRoom() {
        Room room = service.getByRoomNumber("101");
        room.setRoomType("Super Deluxe");
        service.updateRoom(room);
        assert service.getByRoomNumber("101").getRoomType().equals("Super Deluxe");
    }

    @Test
    @Order(4)
    void searchRoom() {
        assert service.searchRoom("Deluxe", null, null).size() == 1;
    }

    @Test
    @Order(5)
    void deleteRoom() {
        service.deleteRoomByRoomNumber("101");
        assert service.getByRoomNumber("101") == null;
    }

    @Test
    @Order(6)
    void addReservation() {
        // builder pattern for reservation model
        Reservation reservation = Reservation.builder().
                customerId(2L).
                room(new Room()).
                toDate(null).
                fromDate(null).
                build();
        service.addReservation(reservation);
        assert service.getReservationById(reservation.getReservationId()) != null;
    }

    @Test
    @Order(7)
    void updateReservation() {
        Reservation reservation = service.getReservationByCustomerId(2L);
        reservation.setCustomerId(3L);
        Long id = reservation.getReservationId();
        service.updateReservation(reservation);
        assert service.getReservationById(id).getCustomerId() == 3L;
    }

    @Order(8)
    @Test
    void getReservation() {
        assert service.getReservationByCustomerId(3L).getCustomerId() == 3L;
    }

    @Test
    @Order(9)
    void deleteReservation() {
        assert service.getReservationByCustomerId(3L) == null;
    }

    @Test
    @Order(10)
    void dtoCheck() {
        ReservationDto r = new ReservationDto();
        if (r == null) {
            throw new ReservationNotFoundException("reservation not found");
        }
        assert r != null;
    }



}
