import { Component, OnInit } from '@angular/core';
import { BackendApiService } from 'src/app/backend-api.service';
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-my-booking',
  templateUrl: './my-booking.component.html',
  styleUrls: ['./my-booking.component.css']
})
export class MyBookingComponent implements OnInit {
  displayTbale:boolean = true;
  displayedColumns: string[] = ['reservationId', 'customerId', 'roomId', 'roomNbr', 'roomType', 'isBooked', 'fromDate', 'toDate'];
  dataSource = [];
  roomBookedmessage:string="";
  status:boolean=false;

  constructor(private router: Router,private backend:BackendApiService) { }

  ngOnInit(): void {
    this.backend.reservations().subscribe(
      (data:any) =>{
        this.dataSource=data
      },
      (error:any) =>{
        console.error(error)
      }
    )
  }
  deleteUser(element:any){
    this.backend.deleteroom(element).subscribe(
      (data:any)=>{
        if(data['message']){
          window.location.reload();
          this.status=true;
          this.roomBookedmessage=data['message'];
        }
      },
      (error:any)=>{
        if(error['message']){
          this.status=true;
          this.roomBookedmessage=error['message'];
        }
        
      }
    )
    console.log(element)
  }
  routerNavigate(url: string) {
    this.router.navigate([`/${url}`])
  }
}
