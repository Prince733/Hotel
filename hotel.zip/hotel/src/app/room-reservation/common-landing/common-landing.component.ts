import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-landing',
  templateUrl: './common-landing.component.html',
  styleUrls: ['./common-landing.component.css']
})
export class CommonLandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
